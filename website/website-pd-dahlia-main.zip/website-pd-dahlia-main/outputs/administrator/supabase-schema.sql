-- ============================================
-- PD Dahlia — Supabase Schema
-- ============================================

-- 1. TABEL PRODUK
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  nama text not null,
  emoji text default '🥩',
  deskripsi text default '',
  chips text[] default '{}',
  harga_min int default 0,
  harga_max int default 0,
  unit text default 'kg',
  aktif boolean default true,
  tersedia boolean default true,
  urutan int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 2. TABEL PENGATURAN (single row, id = 1)
create table if not exists public.settings (
  id int primary key default 1,
  wa_number text default '6281234567890',
  jam_operasional text default '06.00 – 17.00 WIB',
  area_kirim text[] default array['Bandung','Cimahi','Kabupaten Bandung','Bandung Barat'],
  hero_headline text default 'Daging sapi segar, harga jelas, dikirim hari ini.',
  hero_subheadline text default 'PD Dahlia memasok gajih cilok, tulang rangu, iga, dan kikil untuk warung bakso, pedagang cilok, catering, dan rumah tangga di Bandung & sekitarnya.',
  stok_catatan text default 'Stok bergerak cepat, terutama menjelang akhir pekan.',
  stok_tanggal date default current_date,
  updated_at timestamptz default now(),
  constraint settings_single_row check (id = 1)
);

insert into public.settings (id) values (1) on conflict (id) do nothing;

-- 3. ROW LEVEL SECURITY
alter table public.products enable row level security;
alter table public.settings enable row level security;

drop policy if exists "public read active products" on public.products;
drop policy if exists "auth full products" on public.products;
drop policy if exists "admin full products" on public.products;
drop policy if exists "public read settings" on public.settings;
drop policy if exists "auth full settings" on public.settings;
drop policy if exists "admin full settings" on public.settings;

create policy "public read active products" on public.products
  for select using (aktif = true);
create policy "public read settings" on public.settings
  for select using (true);
create policy "admin full products" on public.products
  for all to authenticated using ((auth.jwt() ->> 'email') = 'admin@pd-dahlia.com') with check ((auth.jwt() ->> 'email') = 'admin@pd-dahlia.com');
create policy "admin full settings" on public.settings
  for all to authenticated using ((auth.jwt() ->> 'email') = 'admin@pd-dahlia.com') with check ((auth.jwt() ->> 'email') = 'admin@pd-dahlia.com');

-- 4. AUTO-UPDATE updated_at
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

drop trigger if exists trg_products_updated on public.products;
create trigger trg_products_updated before update on public.products
  for each row execute function public.set_updated_at();

drop trigger if exists trg_settings_updated on public.settings;
create trigger trg_settings_updated before update on public.settings
  for each row execute function public.set_updated_at();

-- 5. SEED DATA (hanya jika tabel kosong)
do $$
begin
  if (select count(*) from public.products) = 0 then
    insert into public.products (nama, emoji, deskripsi, chips, harga_min, harga_max, urutan) values
      ('Gajih Cilok', '🥩', 'Gajih bersih, tidak berbau, tekstur padat. Bikin cilok dan bakso lebih gurih tanpa membuat kuah keruh.', array['Bakso','Cilok','Olahan'], 25000, 25000, 1),
      ('Tulang Rangu', '🦴', 'Kaya kolagen, kaldu lebih pekat dan tetap bening. Andalan warung yang jualan berkuah.', array['Sop','Kaldu','Warung makan'], 28000, 28000, 2),
      ('Iga Sapi', '🍖', 'Potongan rapi, daging menempel tebal, sedikit lemak. Pas untuk sup iga, empal, atau grill.', array['Sup iga','Empal','Grill'], 95000, 95000, 3),
      ('Kikil', '🥣', 'Sudah direbus, empuk, tidak alot. Siap diolah jadi kikil cabe ijo atau gulai.', array['Gulai','Cabe ijo','Catering'], 38000, 38000, 4);
  end if;
end $$;


