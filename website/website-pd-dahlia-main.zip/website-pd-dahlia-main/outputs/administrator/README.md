# Administrator PD Dahlia

Panel administrator untuk mengelola website PD Dahlia.

## Sambungkan ke Supabase sebelum deploy

1. Jalankan `supabase-schema.sql` di Supabase SQL Editor.
2. Buat user `admin@pd-dahlia.com` di Supabase Authentication.
3. Buka `index.html` dan Project URL sudah diisi. Ganti `ISI_ANON_PUBLIC_KEY_ANDA` pada konstanta `SUPABASE_ANON_KEY` dengan publishable key lengkap dari Supabase Settings → API (biasanya berawalan `sb_publishable_`).
4. Jangan gunakan `service_role` key.
5. Deploy isi folder ini ke situs Netlify admin.

`PUBLIC_SITE_URL` sudah diarahkan ke `https://pd-dahlia-website.netlify.app`. Jika kredensial masih berupa teks `ISI_...`, halaman akan menampilkan “Setup Diperlukan” sampai nilainya diganti.

Supabase JS dimuat dari CDN jsDelivr memakai versi stabil yang dipatok agar URL dependensi tidak berubah otomatis.

