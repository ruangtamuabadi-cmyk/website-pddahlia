# PD Dahlia — Website dan Administrator

Paket ini memiliki dua halaman utama yang berbeda tetapi membaca/menyimpan data toko yang sama:

- **Website pelanggan:** folder `website/` (`index.html` + `public-integration.js`)
- **Administrator:** folder `administrator/` (`index.html`)
- **Database:** `supabase-schema.sql`

Perubahan produk, harga, stok, nomor WhatsApp, area kirim, dan teks utama dari Administrator akan tampil di Website publik. Website membaca ulang maksimal setiap 1 menit; `?nocache=1` memaksa data terbaru.

## Hubungkan database

1. Buat project di Supabase.
2. Buka SQL Editor, jalankan seluruh file `supabase-schema.sql` sekali.
3. Di Authentication, buat user dengan email **admin@pd-dahlia.com** dan password kuat. Email ini dipakai oleh aturan akses database; jika memilih email lain, ubah juga dua kebijakan admin di SQL sebelum menjalankannya.
4. Salin Project URL dan **anon/public key** dari Project Settings → API.
5. Buka `website/public-integration.js`, isi `SUPABASE_URL` dan `SUPABASE_ANON_KEY`.
6. Buka `administrator/index.html`, isi dua nilai yang sama pada konstanta `SUPABASE_URL` dan `SUPABASE_ANON_KEY`.
7. Di `administrator/index.html`, ganti `PUBLIC_SITE_URL` dengan alamat website publik setelah deploy.

Gunakan hanya anon/public key di kedua file. Jangan pernah memasukkan `service_role` key ke file browser.

## Terbitkan dua index terpisah

Website dan admin harus berada di dua situs/folder hosting yang berbeda. Di Netlify Drop atau hosting serupa:

1. Deploy isi folder `website/` sebagai satu situs (folder itu sudah memiliki `index.html` dan `public-integration.js`).
2. Deploy isi folder `administrator/` sebagai situs kedua. File `index.html` di folder ini menjadi index administrator.
3. Kembali ke pengaturan Administrator, isi `PUBLIC_SITE_URL` dengan URL situs website lalu deploy ulang Administrator.
4. Buka URL admin, masuk dengan email/password yang dibuat pada langkah 3. Dari Dashboard, tombol website membuka halaman publik.

## Yang bisa dikelola dari Administrator

- Tambah, ubah, hapus, urutkan dan sembunyikan produk
- Harga minimum/maksimum, satuan, deskripsi dan label kegunaan
- Ketersediaan stok dan catatan stok harian
- Nomor WhatsApp, jam operasional, area kirim, headline dan subheadline

WhatsApp awal memakai nomor contoh dari bahan lampiran. Ganti nomor tersebut dari Pengaturan sebelum website digunakan pelanggan. Harga awal adalah contoh dan harus diperiksa admin.

## Catatan

Ini paket sumber siap dikonfigurasi, bukan situs yang sudah dipublikasikan atau project Supabase yang sudah dibuat. Sinkronisasi online aktif setelah URL/key Supabase diisi dan kedua situs di-deploy. Pastikan tabel dan kebijakan RLS berhasil dibuat sebelum login.
